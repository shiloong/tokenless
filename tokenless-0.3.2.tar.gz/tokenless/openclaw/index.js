// ../../../tokenless/openclaw/index.ts
import { execSync, execFileSync, spawnSync } from "child_process";
import { existsSync, statSync } from "fs";
var sessionMap = /* @__PURE__ */ new Map();
var rtkAvailable = null;
var tokenlessAvailable = null;
var toonAvailable = null;
var rtkPath = "rtk";
var tokenlessPath = "tokenless";
var toonPath = "toon";
var LIBEXEC_FALLBACK = "/usr/libexec/tokenless";
function isExecutable(path) {
  try {
    return existsSync(path) && (statSync(path).mode & 73) !== 0;
  } catch {
    return false;
  }
}
function checkRtk() {
  if (rtkAvailable !== null) return rtkAvailable;
  try {
    const result = execSync("which rtk 2>/dev/null || echo ''", { encoding: "utf-8" }).trim();
    if (result && result !== "") {
      rtkPath = result;
      rtkAvailable = true;
    } else if (isExecutable(`${LIBEXEC_FALLBACK}/rtk`)) {
      rtkPath = `${LIBEXEC_FALLBACK}/rtk`;
      rtkAvailable = true;
    } else {
      rtkAvailable = false;
    }
  } catch {
    if (isExecutable(`${LIBEXEC_FALLBACK}/rtk`)) {
      rtkPath = `${LIBEXEC_FALLBACK}/rtk`;
      rtkAvailable = true;
    } else {
      rtkAvailable = false;
    }
    return rtkAvailable;
  }
  return rtkAvailable;
}
function isSkillContent(message) {
  if (typeof message !== "string") return false;
  const trimmed = message.trimStart();
  if (!trimmed.startsWith("---")) return false;
  const firstLines = trimmed.split("\n", 20).join("\n");
  return /^name:/m.test(firstLines) || /^description:/m.test(firstLines);
}
function checkTokenless() {
  if (tokenlessAvailable !== null) return tokenlessAvailable;
  try {
    const result = execSync("which tokenless 2>/dev/null || echo ''", { encoding: "utf-8" }).trim();
    if (result && result !== "") {
      tokenlessPath = result;
      tokenlessAvailable = true;
    } else if (isExecutable(`${LIBEXEC_FALLBACK}/tokenless`)) {
      tokenlessPath = `${LIBEXEC_FALLBACK}/tokenless`;
      tokenlessAvailable = true;
    } else {
      tokenlessAvailable = false;
    }
  } catch {
    if (isExecutable(`${LIBEXEC_FALLBACK}/tokenless`)) {
      tokenlessPath = `${LIBEXEC_FALLBACK}/tokenless`;
      tokenlessAvailable = true;
    } else {
      tokenlessAvailable = false;
    }
    return tokenlessAvailable;
  }
  return tokenlessAvailable;
}
function checkToon() {
  if (toonAvailable !== null) return toonAvailable;
  try {
    const result = execSync("which toon 2>/dev/null || echo ''", { encoding: "utf-8" }).trim();
    if (result && result !== "") {
      toonPath = result;
      toonAvailable = true;
    } else if (isExecutable(`${LIBEXEC_FALLBACK}/toon`)) {
      toonPath = `${LIBEXEC_FALLBACK}/toon`;
      toonAvailable = true;
    } else {
      toonAvailable = false;
    }
  } catch {
    if (isExecutable(`${LIBEXEC_FALLBACK}/toon`)) {
      toonPath = `${LIBEXEC_FALLBACK}/toon`;
      toonAvailable = true;
    } else {
      toonAvailable = false;
    }
    return toonAvailable;
  }
  return toonAvailable;
}
function tryRtkRewrite(command) {
  try {
    const result = spawnSync(rtkPath, ["rewrite", command], {
      encoding: "utf-8",
      timeout: 2e3,
      stdio: ["ignore", "pipe", "pipe"]
    });
    const rewritten = result.stdout?.trim();
    if ((result.status === 0 || result.status === 3) && rewritten && rewritten !== command) {
      return rewritten;
    }
    return null;
  } catch {
    return null;
  }
}
function tryCompressResponse(response, sessionId, toolCallId) {
  try {
    const input = JSON.stringify(response);
    const args = ["compress-response", "--agent-id", "openclaw"];
    if (sessionId) args.push("--session-id", sessionId);
    if (toolCallId) args.push("--tool-use-id", toolCallId);
    const result = execFileSync(tokenlessPath, args, {
      encoding: "utf-8",
      timeout: 3e3,
      input
    }).trim();
    if (result === input) {
      return null;
    }
    return JSON.parse(result);
  } catch {
    return null;
  }
}
function tryEnvCheck(toolName) {
  try {
    const result = execFileSync(tokenlessPath, ["env-check", "--tool", toolName, "--json"], {
      encoding: "utf-8",
      timeout: 3e3
    }).trim();
    const parsed = JSON.parse(result);
    const status = parsed.status || "UNKNOWN";
    if (status === "UNKNOWN" || status === "READY") return null;
    const fixResult = execFileSync(tokenlessPath, ["env-check", "--tool", toolName, "--fix", "--json"], {
      encoding: "utf-8",
      timeout: 1e4
    }).trim();
    const fixParsed = JSON.parse(fixResult);
    const postStatus = fixParsed.status || "NOT_READY";
    if (postStatus === "READY") return null;
    const diagnostic = fixParsed.diagnostic || `[tokenless tool-ready] ${toolName}: NOT_READY \u2014 environment issue. Skip retry.`;
    return { status: postStatus, diagnostic };
  } catch {
    return null;
  }
}
var index_default = {
  id: "tokenless-openclaw",
  name: "Token-Less",
  version: "1.0.0",
  description: "Unified RTK command rewriting + schema/response/TOON compression + Tool Ready",
  register(api) {
    const pluginConfig = api.config ?? {};
    const rtkEnabled = pluginConfig.rtk_enabled !== false;
    const responseCompressionEnabled = pluginConfig.response_compression_enabled !== false;
    const toonCompressionEnabled = pluginConfig.toon_compression_enabled !== false;
    const toolReadyEnabled = pluginConfig.tool_ready_enabled !== false;
    const skipTools = new Set((pluginConfig.skip_tools ?? ["Read", "read_file", "Glob", "list_directory", "NotebookRead"]).map((t) => t.toLowerCase()));
    const verbose = pluginConfig.verbose !== false;
    api.on(
      "session_start",
      (event) => {
        if (event.sessionKey && event.sessionId) {
          sessionMap.set(event.sessionKey, event.sessionId);
        }
        process.env.TOKENLESS_SESSION_ID = event.sessionId;
      }
    );
    if (toolReadyEnabled && checkTokenless()) {
      api.on(
        "before_tool_call",
        (event, ctx) => {
          const result = tryEnvCheck(event.toolName);
          if (!result) return;
          if (verbose) {
            console.log(`[tokenless/tool-ready] ${event.toolName}: ${result.status} \u2014 tool not available`);
          }
          return { contextPrefix: result.diagnostic };
        },
        { priority: 5 }
      );
    }
    if (rtkEnabled && checkRtk()) {
      api.on(
        "before_tool_call",
        (event, ctx) => {
          if (event.toolName !== "exec") return;
          const command = event.params?.command;
          if (typeof command !== "string") return;
          process.env.TOKENLESS_AGENT_ID = "openclaw";
          if (ctx?.sessionId) process.env.TOKENLESS_SESSION_ID = ctx.sessionId;
          if (ctx?.toolCallId) process.env.TOKENLESS_TOOL_USE_ID = ctx.toolCallId;
          const rewritten = tryRtkRewrite(command);
          if (!rewritten) return;
          if (verbose) {
            console.log(`[tokenless/rtk] rewrite: ${command} -> ${rewritten}`);
          }
          return { params: { ...event.params, command: rewritten } };
        },
        { priority: 10 }
      );
    }
    if (checkTokenless() && (responseCompressionEnabled || toonCompressionEnabled)) {
      api.on(
        "tool_result_persist",
        (event, ctx) => {
          const beforeJson = JSON.stringify(event.message);
          if (beforeJson.length < 200) return;
          if (event.toolName && skipTools.has(event.toolName.toLowerCase())) return;
          if (isSkillContent(event.message)) return;
          const toolCallId = ctx?.toolCallId || event.toolCallId;
          const sessionId = ctx?.sessionId || ctx?.sessionKey && sessionMap.get(ctx.sessionKey) || process.env.TOKENLESS_SESSION_ID || ctx?.sessionKey;
          let currentMessage = event.message;
          let usedResponseCompression = false;
          if (responseCompressionEnabled) {
            const compressed = tryCompressResponse(currentMessage, sessionId, toolCallId);
            if (compressed) {
              currentMessage = compressed;
              usedResponseCompression = true;
            }
          }
          let usedToon = false;
          let toonText = "";
          if (toonCompressionEnabled && checkToon()) {
            try {
              const jsonInput = JSON.stringify(currentMessage);
              const result = execFileSync(toonPath, ["-e"], {
                encoding: "utf-8",
                timeout: 3e3,
                input: jsonInput
              }).trim();
              if (result) {
                toonText = result;
                usedToon = true;
              }
            } catch {
            }
          }
          if (!usedResponseCompression && !usedToon) return;
          let finalMessage;
          let savingsLabel;
          let totalSavingsPct;
          if (usedToon) {
            const before = JSON.stringify(event.message).length;
            const after = toonText.length;
            totalSavingsPct = before > 0 ? Math.round((before - after) / before * 100) : 0;
            savingsLabel = usedResponseCompression ? "response compressed + TOON encoded" : "TOON encoded";
            const toonWrapped = `[TOON format, ${totalSavingsPct}% token savings]
${toonText}`;
            if (typeof event.message === "object" && event.message?.role === "toolResult") {
              finalMessage = {
                ...event.message,
                content: [{ type: "text", text: toonWrapped }]
              };
            } else {
              finalMessage = toonWrapped;
            }
          } else {
            const before = JSON.stringify(event.message).length;
            const after = JSON.stringify(currentMessage).length;
            totalSavingsPct = before > 0 ? Math.round((before - after) / before * 100) : 0;
            savingsLabel = "response compressed";
            finalMessage = currentMessage;
          }
          if (verbose) {
            const before = JSON.stringify(event.message).length;
            const after = usedToon ? toonText.length : JSON.stringify(finalMessage).length;
            console.log(
              `[tokenless/${savingsLabel}] ${event.toolName}: ${before} -> ${after} chars (${totalSavingsPct}% reduction)`
            );
          }
          return { message: finalMessage };
        },
        { priority: 10 }
      );
    }
    if (verbose) {
      checkToon();
      const features = [
        rtkEnabled && rtkAvailable ? "rtk-rewrite" : null,
        toolReadyEnabled && tokenlessAvailable ? "tool-ready" : null,
        responseCompressionEnabled && tokenlessAvailable ? "response-compression" : null,
        toonCompressionEnabled && toonAvailable ? "toon-compression" : null
      ].filter(Boolean);
      console.log(`[tokenless] OpenClaw plugin registered \u2014 active features: ${features.join(", ") || "none"}`);
    }
  }
};
export {
  index_default as default
};
